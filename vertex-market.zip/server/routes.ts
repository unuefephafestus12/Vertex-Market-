import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import {
  insertInvestmentSchema,
  insertTransactionSchema,
  insertWithdrawalSchema,
  insertTestimonialSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Cryptocurrency routes
  app.get("/api/cryptos", async (req, res, next) => {
    try {
      const cryptos = await storage.getCryptos();
      res.json(cryptos);
    } catch (error) {
      next(error);
    }
  });

  // Investment routes
  app.get("/api/investments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      const investments = await storage.getInvestments(userId);
      res.json(investments);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/investments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      
      const validatedData = insertInvestmentSchema.parse({
        ...req.body,
        userId
      });
      
      const investment = await storage.createInvestment(validatedData);
      res.status(201).json(investment);
    } catch (error) {
      next(error);
    }
  });

  // Transaction routes
  app.get("/api/transactions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/transactions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      
      const validatedData = insertTransactionSchema.parse({
        ...req.body,
        userId
      });
      
      const transaction = await storage.createTransaction(validatedData);
      res.status(201).json(transaction);
    } catch (error) {
      next(error);
    }
  });

  // Withdrawal routes
  app.get("/api/withdrawals", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      const withdrawals = await storage.getWithdrawals(userId);
      res.json(withdrawals);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/withdrawals", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      
      const validatedData = insertWithdrawalSchema.parse({
        ...req.body,
        userId,
        status: "pending" // Always set initial status to pending
      });
      
      const withdrawal = await storage.createWithdrawal(validatedData);
      res.status(201).json(withdrawal);
    } catch (error) {
      next(error);
    }
  });

  // Testimonial routes
  app.get("/api/testimonials", async (req, res, next) => {
    try {
      const testimonials = await storage.getTestimonials();
      res.json(testimonials);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/testimonials", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const validatedData = insertTestimonialSchema.parse(req.body);
      const testimonial = await storage.createTestimonial(validatedData);
      res.status(201).json(testimonial);
    } catch (error) {
      next(error);
    }
  });

  // FAQ routes
  app.get("/api/faqs", async (req, res, next) => {
    try {
      const faqs = await storage.getFaqs();
      res.json(faqs);
    } catch (error) {
      next(error);
    }
  });

  // Asset allocation routes
  app.get("/api/asset-allocation", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      const allocations = await storage.getAssetAllocation(userId);
      res.json(allocations);
    } catch (error) {
      next(error);
    }
  });

  // Dashboard summary route
  app.get("/api/dashboard/summary", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const userId = (req.user as Express.User).id;
      
      // Get all user investments
      const investments = await storage.getInvestments(userId);
      
      // Calculate totals
      const totalInvested = investments.reduce((sum, inv) => sum + parseFloat(inv.amount.toString()), 0);
      const currentValue = investments.reduce((sum, inv) => sum + parseFloat(inv.currentValue.toString()), 0);
      const totalProfit = investments.reduce((sum, inv) => sum + parseFloat(inv.profit.toString()), 0);
      
      // Get recent transactions
      const recentTransactions = (await storage.getTransactions(userId)).slice(0, 5);
      
      // Get asset allocation
      const assetAllocation = await storage.getAssetAllocation(userId);
      
      res.json({
        totalInvested,
        currentValue,
        totalProfit,
        profitPercentage: totalInvested > 0 ? (totalProfit / totalInvested) * 100 : 0,
        recentTransactions,
        assetAllocation
      });
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
