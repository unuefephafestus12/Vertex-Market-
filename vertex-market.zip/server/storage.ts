import { 
  users, User, InsertUser, 
  cryptocurrencies, Crypto, InsertCrypto,
  investments, Investment, InsertInvestment,
  transactions, Transaction, InsertTransaction,
  withdrawalRequests, Withdrawal, InsertWithdrawal,
  testimonials, Testimonial, InsertTestimonial,
  faqs, Faq, InsertFaq,
  assetAllocation, AssetAllocation, InsertAssetAllocation
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Crypto methods
  getCryptos(): Promise<Crypto[]>;
  getCrypto(id: number): Promise<Crypto | undefined>;
  getCryptoBySymbol(symbol: string): Promise<Crypto | undefined>;
  createCrypto(crypto: InsertCrypto): Promise<Crypto>;
  updateCrypto(id: number, data: Partial<InsertCrypto>): Promise<Crypto | undefined>;
  
  // Investment methods
  getInvestments(userId: number): Promise<Investment[]>;
  getInvestment(id: number): Promise<Investment | undefined>;
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  updateInvestment(id: number, data: Partial<InsertInvestment>): Promise<Investment | undefined>;
  
  // Transaction methods
  getTransactions(userId: number): Promise<Transaction[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Withdrawal methods
  getWithdrawals(userId: number): Promise<Withdrawal[]>;
  getWithdrawal(id: number): Promise<Withdrawal | undefined>;
  createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal>;
  updateWithdrawalStatus(id: number, status: string): Promise<Withdrawal | undefined>;
  
  // Testimonial methods
  getTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  
  // FAQ methods
  getFaqs(): Promise<Faq[]>;
  
  // Asset Allocation methods
  getAssetAllocation(userId: number): Promise<AssetAllocation[]>;
  setAssetAllocation(allocation: InsertAssetAllocation): Promise<AssetAllocation>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private cryptos: Map<number, Crypto>;
  private investments: Map<number, Investment>;
  private transactions: Map<number, Transaction>;
  private withdrawals: Map<number, Withdrawal>;
  private testimonialsList: Map<number, Testimonial>;
  private faqsList: Map<number, Faq>;
  private assetAllocations: Map<number, AssetAllocation>;
  sessionStore: session.SessionStore;
  
  private userIdCounter: number = 1;
  private cryptoIdCounter: number = 1;
  private investmentIdCounter: number = 1;
  private transactionIdCounter: number = 1;
  private withdrawalIdCounter: number = 1;
  private testimonialIdCounter: number = 1;
  private faqIdCounter: number = 1;
  private assetAllocationIdCounter: number = 1;

  constructor() {
    this.users = new Map();
    this.cryptos = new Map();
    this.investments = new Map();
    this.transactions = new Map();
    this.withdrawals = new Map();
    this.testimonialsList = new Map();
    this.faqsList = new Map();
    this.assetAllocations = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    
    // Initialize with sample data
    this.initData();
  }

  private initData() {
    // Add some cryptocurrencies
    const cryptos: InsertCrypto[] = [
      { name: "Bitcoin", symbol: "BTC", price: "43241.56", change24h: "5.24", marketCap: "817500000000", vertexROI: "16.8" },
      { name: "Ethereum", symbol: "ETH", price: "3521.89", change24h: "3.78", marketCap: "421600000000", vertexROI: "21.2" },
      { name: "Solana", symbol: "SOL", price: "101.32", change24h: "-1.24", marketCap: "35200000000", vertexROI: "28.7" },
      { name: "Cardano", symbol: "ADA", price: "0.57", change24h: "2.16", marketCap: "18700000000", vertexROI: "15.3" }
    ];
    
    cryptos.forEach(crypto => this.createCrypto(crypto));
    
    // Add some FAQs
    const faqs: InsertFaq[] = [
      { question: "How does Vertex Market generate returns?", answer: "Our team of expert traders employs advanced trading strategies across multiple cryptocurrency markets. We combine technical analysis, market sentiment evaluation, and risk management protocols to identify profitable trading opportunities while protecting your capital.", order: 1 },
      { question: "What are the minimum and maximum investment amounts?", answer: "The minimum investment amount is $250 to start your portfolio. There is no maximum limit, and we work with investors of all sizes, from individual traders to institutional clients.", order: 2 },
      { question: "How do withdrawals work?", answer: "You can request a withdrawal at any time through your dashboard. Standard withdrawals are processed within 24 hours, and the funds are sent to your registered bank account or cryptocurrency wallet. There are no withdrawal fees, but standard network fees may apply for cryptocurrency withdrawals.", order: 3 },
      { question: "Is my investment safe with Vertex Market?", answer: "We prioritize security above all else. Your funds are stored in cold wallets with military-grade encryption, and we employ strict risk management protocols to protect against market volatility. Additionally, we maintain a reserve fund to ensure liquidity and operational stability.", order: 4 },
      { question: "What fees does Vertex Market charge?", answer: "We operate on a simple, transparent fee structure: a 2% annual management fee and a 20% performance fee on profits. There are no hidden charges, setup fees, or withdrawal fees.", order: 5 }
    ];
    
    faqs.forEach(faq => {
      const id = this.faqIdCounter++;
      this.faqsList.set(id, { ...faq, id });
    });
    
    // Add testimonials
    const testimonials: InsertTestimonial[] = [
      { name: "David Chen", profession: "Software Engineer", content: "I've been investing with Vertex Market for 8 months now, and the results have exceeded my expectations. The platform is intuitive, and their team is always responsive to my questions.", rating: 5, verified: true },
      { name: "Sarah Johnson", profession: "Marketing Director", content: "As someone new to cryptocurrency investing, I was hesitant at first. Vertex Market made the process simple, and their educational resources helped me understand exactly what I was investing in.", rating: 5, verified: true },
      { name: "Michael Rodriguez", profession: "Financial Analyst", content: "What impressed me most was how transparent Vertex Market is about their trading strategies and fee structure. No hidden costs, and withdrawals are processed quickly. I've recommended them to all my colleagues.", rating: 4, verified: true }
    ];
    
    testimonials.forEach(testimonial => {
      const id = this.testimonialIdCounter++;
      this.testimonialsList.set(id, { ...testimonial, id });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const timestamp = new Date();
    const newUser: User = { ...user, id, createdAt: timestamp };
    this.users.set(id, newUser);
    return newUser;
  }

  // Crypto methods
  async getCryptos(): Promise<Crypto[]> {
    return Array.from(this.cryptos.values());
  }

  async getCrypto(id: number): Promise<Crypto | undefined> {
    return this.cryptos.get(id);
  }

  async getCryptoBySymbol(symbol: string): Promise<Crypto | undefined> {
    return Array.from(this.cryptos.values()).find(
      (crypto) => crypto.symbol === symbol,
    );
  }

  async createCrypto(crypto: InsertCrypto): Promise<Crypto> {
    const id = this.cryptoIdCounter++;
    const newCrypto: Crypto = { ...crypto, id };
    this.cryptos.set(id, newCrypto);
    return newCrypto;
  }

  async updateCrypto(id: number, data: Partial<InsertCrypto>): Promise<Crypto | undefined> {
    const crypto = this.cryptos.get(id);
    if (!crypto) return undefined;
    
    const updatedCrypto = { ...crypto, ...data };
    this.cryptos.set(id, updatedCrypto);
    return updatedCrypto;
  }

  // Investment methods
  async getInvestments(userId: number): Promise<Investment[]> {
    return Array.from(this.investments.values()).filter(
      (investment) => investment.userId === userId,
    );
  }

  async getInvestment(id: number): Promise<Investment | undefined> {
    return this.investments.get(id);
  }

  async createInvestment(investment: InsertInvestment): Promise<Investment> {
    const id = this.investmentIdCounter++;
    const timestamp = new Date();
    const newInvestment: Investment = { ...investment, id, createdAt: timestamp };
    this.investments.set(id, newInvestment);
    return newInvestment;
  }

  async updateInvestment(id: number, data: Partial<InsertInvestment>): Promise<Investment | undefined> {
    const investment = this.investments.get(id);
    if (!investment) return undefined;
    
    const updatedInvestment = { ...investment, ...data };
    this.investments.set(id, updatedInvestment);
    return updatedInvestment;
  }

  // Transaction methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.userId === userId)
      .sort((a, b) => b.date.getTime() - a.date.getTime()); // Sort by date desc
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionIdCounter++;
    const timestamp = new Date();
    const newTransaction: Transaction = { ...transaction, id, date: timestamp };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  // Withdrawal methods
  async getWithdrawals(userId: number): Promise<Withdrawal[]> {
    return Array.from(this.withdrawals.values())
      .filter((withdrawal) => withdrawal.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()); // Sort by date desc
  }

  async getWithdrawal(id: number): Promise<Withdrawal | undefined> {
    return this.withdrawals.get(id);
  }

  async createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const id = this.withdrawalIdCounter++;
    const timestamp = new Date();
    const newWithdrawal: Withdrawal = { ...withdrawal, id, createdAt: timestamp };
    this.withdrawals.set(id, newWithdrawal);
    return newWithdrawal;
  }

  async updateWithdrawalStatus(id: number, status: string): Promise<Withdrawal | undefined> {
    const withdrawal = this.withdrawals.get(id);
    if (!withdrawal) return undefined;
    
    const updatedWithdrawal = { ...withdrawal, status };
    this.withdrawals.set(id, updatedWithdrawal);
    return updatedWithdrawal;
  }

  // Testimonial methods
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonialsList.values());
  }

  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.testimonialIdCounter++;
    const newTestimonial: Testimonial = { ...testimonial, id };
    this.testimonialsList.set(id, newTestimonial);
    return newTestimonial;
  }

  // FAQ methods
  async getFaqs(): Promise<Faq[]> {
    return Array.from(this.faqsList.values())
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  // Asset Allocation methods
  async getAssetAllocation(userId: number): Promise<AssetAllocation[]> {
    return Array.from(this.assetAllocations.values())
      .filter((allocation) => allocation.userId === userId);
  }

  async setAssetAllocation(allocation: InsertAssetAllocation): Promise<AssetAllocation> {
    // Check if allocation already exists and update or create
    const existing = Array.from(this.assetAllocations.values()).find(
      (a) => a.userId === allocation.userId && a.cryptoId === allocation.cryptoId
    );
    
    if (existing) {
      const updated = { ...existing, percentage: allocation.percentage };
      this.assetAllocations.set(existing.id, updated);
      return updated;
    } else {
      const id = this.assetAllocationIdCounter++;
      const newAllocation: AssetAllocation = { ...allocation, id };
      this.assetAllocations.set(id, newAllocation);
      return newAllocation;
    }
  }
}

export const storage = new MemStorage();
