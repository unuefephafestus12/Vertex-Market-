import { Card, CardContent } from "@/components/ui/card";

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900">About Vertex Market</h1>
        <p className="mt-4 text-xl text-gray-600">
          Your trusted partner for expert-managed cryptocurrency investments.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
          <p className="text-gray-700 mb-4">
            At Vertex Market, our mission is to democratize access to the cryptocurrency market by providing professional trading services to investors of all sizes. We believe that everyone should have the opportunity to benefit from the growth potential of digital assets, without requiring specialized knowledge or dedicating countless hours to market analysis.
          </p>
          <p className="text-gray-700">
            We combine cutting-edge technology with expert human oversight to create a secure, transparent, and profitable investment environment for our clients. Our team is passionate about blockchain technology and committed to maintaining the highest standards of integrity and performance.
          </p>
        </div>
        <div className="bg-gradient-to-r from-primary to-primary-dark text-white rounded-xl p-8">
          <h2 className="text-2xl font-bold mb-4">Why Choose Vertex Market</h2>
          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="text-amber-400 mr-2">✓</span>
              <span>Expert team with proven track record in cryptocurrency trading</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-400 mr-2">✓</span>
              <span>Transparent fee structure with no hidden costs</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-400 mr-2">✓</span>
              <span>Robust security measures to protect your investments</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-400 mr-2">✓</span>
              <span>Real-time performance tracking and detailed reports</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-400 mr-2">✓</span>
              <span>Responsive customer support available 24/7</span>
            </li>
            <li className="flex items-start">
              <span className="text-amber-400 mr-2">✓</span>
              <span>Flexible investment options with no lock-in periods</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Our Leadership Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-center mb-4">
                <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-12 w-12"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                </div>
              </div>
              <h3 className="text-xl font-bold text-center">Jonathan Chen</h3>
              <p className="text-gray-500 text-center mb-4">CEO & Founder</p>
              <p className="text-gray-700 text-sm">
                With over 15 years of experience in financial markets and 7 years specializing in cryptocurrency trading, Jonathan leads our strategic vision and trading operations.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-center mb-4">
                <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-12 w-12"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                </div>
              </div>
              <h3 className="text-xl font-bold text-center">Dr. Sarah Williams</h3>
              <p className="text-gray-500 text-center mb-4">CTO</p>
              <p className="text-gray-700 text-sm">
                A blockchain researcher with a Ph.D. in Cryptography, Sarah oversees our trading algorithms and security protocols, ensuring optimal performance and protection.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-center mb-4">
                <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-12 w-12"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                </div>
              </div>
              <h3 className="text-xl font-bold text-center">Michael Rodriguez</h3>
              <p className="text-gray-500 text-center mb-4">Head of Trading</p>
              <p className="text-gray-700 text-sm">
                Former investment banker with a decade of experience in quantitative trading, Michael leads our team of expert traders and develops our market strategies.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Our Approach</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Risk Management</h3>
            <p className="text-gray-700">
              We employ sophisticated risk management techniques to protect your capital. Our strategies include stop-loss protections, diversification across multiple cryptocurrencies, and continual market monitoring to adapt to changing conditions. We maintain strict risk-to-reward ratios and never overleverage positions.
            </p>
          </div>
          
          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Trading Methodology</h3>
            <p className="text-gray-700">
              Our trading approach combines technical analysis, fundamental research, and market sentiment evaluation. We utilize both automated algorithms and human oversight to identify profitable opportunities while avoiding emotional decision-making. This hybrid approach allows us to react quickly to market movements while maintaining strategic oversight.
            </p>
          </div>
          
          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Security Measures</h3>
            <p className="text-gray-700">
              Security is our top priority. We store the majority of assets in cold wallets with multi-signature requirements, utilize 256-bit encryption for all communications, and implement strict access controls. Our systems undergo regular security audits, and we maintain comprehensive insurance coverage to protect against unforeseen events.
            </p>
          </div>
          
          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Transparency</h3>
            <p className="text-gray-700">
              We believe in complete transparency. Our fee structure is clearly defined with no hidden charges. You receive detailed reports on trading performance, and our customer portal provides real-time information on your investment value. We never comingle client funds with operational accounts.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
