import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import StatCard from "@/components/dashboard/stat-card";
import PortfolioChart from "@/components/dashboard/portfolio-chart";
import AssetAllocation from "@/components/dashboard/asset-allocation";
import TransactionsTable from "@/components/dashboard/transactions-table";

// Withdrawal request schema
const withdrawalSchema = z.object({
  amount: z.string().refine(
    (val) => !isNaN(Number(val)) && Number(val) > 0,
    { message: "Amount must be a positive number" }
  ),
  method: z.string().min(1, "Please select a withdrawal method"),
  details: z.string().min(5, "Please provide your account details for the withdrawal"),
});

// Deposit schema
const depositSchema = z.object({
  amount: z.string().refine(
    (val) => !isNaN(Number(val)) && Number(val) > 0,
    { message: "Amount must be a positive number" }
  ),
  asset: z.string().min(1, "Please select an asset"),
});

type WithdrawalFormValues = z.infer<typeof withdrawalSchema>;
type DepositFormValues = z.infer<typeof depositSchema>;

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("portfolio");
  
  // Dashboard summary data
  const { data: dashboardData, isLoading: loadingDashboard } = useQuery({
    queryKey: ["/api/dashboard/summary"],
    enabled: !!user,
  });
  
  // Transactions data
  const { data: transactions, isLoading: loadingTransactions } = useQuery({
    queryKey: ["/api/transactions"],
    enabled: !!user,
  });
  
  // Crypto data
  const { data: cryptos } = useQuery({
    queryKey: ["/api/cryptos"],
  });
  
  // Withdrawal form
  const withdrawalForm = useForm<WithdrawalFormValues>({
    resolver: zodResolver(withdrawalSchema),
    defaultValues: {
      amount: "",
      method: "",
      details: "",
    },
  });
  
  // Deposit form
  const depositForm = useForm<DepositFormValues>({
    resolver: zodResolver(depositSchema),
    defaultValues: {
      amount: "",
      asset: "USD",
    },
  });
  
  // Withdrawal mutation
  const withdrawalMutation = useMutation({
    mutationFn: async (data: WithdrawalFormValues) => {
      const res = await apiRequest("POST", "/api/withdrawals", {
        amount: data.amount,
        method: data.method,
        details: data.details,
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/withdrawals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/summary"] });
      toast({
        title: "Withdrawal request submitted",
        description: "Your withdrawal request is pending approval.",
      });
      withdrawalForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Withdrawal request failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Deposit mutation
  const depositMutation = useMutation({
    mutationFn: async (data: DepositFormValues) => {
      const res = await apiRequest("POST", "/api/transactions", {
        type: "deposit",
        asset: data.asset,
        amount: data.amount,
        status: "completed",
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/summary"] });
      toast({
        title: "Deposit successful",
        description: "Your deposit has been processed successfully.",
      });
      depositForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Deposit failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onWithdrawalSubmit = (data: WithdrawalFormValues) => {
    withdrawalMutation.mutate(data);
  };
  
  const onDepositSubmit = (data: DepositFormValues) => {
    depositMutation.mutate(data);
  };

  if (loadingDashboard) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome, {user?.firstName}</h1>
        <p className="text-gray-600 mt-1">Manage your investment portfolio and track your profits</p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          <TabsTrigger value="deposit">Deposit</TabsTrigger>
          <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
        </TabsList>
        
        <TabsContent value="portfolio" className="space-y-6">
          {/* Statistics Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard 
              title="Initial Investment" 
              value={`$${dashboardData?.totalInvested.toFixed(2) || "0.00"}`}
              icon="dollar"
            />
            <StatCard 
              title="Current Value" 
              value={`$${dashboardData?.currentValue.toFixed(2) || "0.00"}`}
              icon="trending-up"
              valueClassName="text-green-600"
            />
            <StatCard 
              title="Total Profit" 
              value={`${dashboardData?.profitPercentage.toFixed(2) || "0.00"}%`}
              subValue={`$${dashboardData?.totalProfit.toFixed(2) || "0.00"}`}
              icon="chart"
              valueClassName="text-green-600"
            />
          </div>
          
          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Portfolio Performance</CardTitle>
                <CardDescription>Your investment growth over time</CardDescription>
              </CardHeader>
              <CardContent>
                <PortfolioChart />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Asset Allocation</CardTitle>
                <CardDescription>Your investment distribution</CardDescription>
              </CardHeader>
              <CardContent>
                <AssetAllocation />
              </CardContent>
            </Card>
          </div>
          
          {/* Recent Transactions */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Your latest account activities</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingTransactions ? (
                <div className="flex justify-center py-6">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : (
                <TransactionsTable 
                  transactions={transactions ? transactions.slice(0, 5) : []} 
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="deposit">
          <Card>
            <CardHeader>
              <CardTitle>Deposit Funds</CardTitle>
              <CardDescription>Add funds to your Vertex Market account</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...depositForm}>
                <form onSubmit={depositForm.handleSubmit(onDepositSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={depositForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                              <Input placeholder="0.00" className="pl-8" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={depositForm.control}
                      name="asset"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Asset</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select asset" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="USD">USD (US Dollar)</SelectItem>
                              <SelectItem value="EUR">EUR (Euro)</SelectItem>
                              <SelectItem value="BTC">BTC (Bitcoin)</SelectItem>
                              <SelectItem value="ETH">ETH (Ethereum)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                    <h3 className="text-sm font-medium text-blue-800 mb-2">Deposit Instructions</h3>
                    <p className="text-sm text-blue-700">
                      After submitting this form, you will receive payment instructions 
                      based on your selected method. Funds will be credited to your account 
                      once payment is confirmed.
                    </p>
                  </div>
                  
                  <Button 
                    type="submit" 
                    disabled={depositMutation.isPending} 
                    className="w-full md:w-auto"
                  >
                    {depositMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Submit Deposit"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="withdraw">
          <Card>
            <CardHeader>
              <CardTitle>Withdraw Funds</CardTitle>
              <CardDescription>Request a withdrawal from your account</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...withdrawalForm}>
                <form onSubmit={withdrawalForm.handleSubmit(onWithdrawalSubmit)} className="space-y-6">
                  <FormField
                    control={withdrawalForm.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Withdrawal Amount</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                            <Input placeholder="0.00" className="pl-8" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={withdrawalForm.control}
                    name="method"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Withdrawal Method</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select method" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="bank">Bank Transfer</SelectItem>
                            <SelectItem value="bitcoin">Bitcoin</SelectItem>
                            <SelectItem value="ethereum">Ethereum</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={withdrawalForm.control}
                    name="details"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Account Details</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your withdrawal account details" {...field} />
                        </FormControl>
                        <FormMessage />
                        <p className="text-sm text-gray-500 mt-1">
                          For bank transfers: provide your bank name, account number, and routing number. 
                          For crypto: provide your wallet address.
                        </p>
                      </FormItem>
                    )}
                  />
                  
                  <div className="p-4 bg-amber-50 rounded-lg border border-amber-100">
                    <h3 className="text-sm font-medium text-amber-800 mb-2">Withdrawal Information</h3>
                    <p className="text-sm text-amber-700">
                      Withdrawals are typically processed within 24 hours. There are no withdrawal
                      fees from Vertex Market, but your bank or crypto network may apply their own fees.
                    </p>
                  </div>
                  
                  <Button 
                    type="submit" 
                    disabled={withdrawalMutation.isPending} 
                    className="w-full md:w-auto"
                  >
                    {withdrawalMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Request Withdrawal"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="transactions">
          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>View all your account activities</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingTransactions ? (
                <div className="flex justify-center py-6">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : (
                <TransactionsTable 
                  transactions={transactions || []} 
                  showPagination
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
