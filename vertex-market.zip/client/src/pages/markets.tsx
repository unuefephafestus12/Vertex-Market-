import { useQuery } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, TrendingUp, TrendingDown, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function MarketsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: cryptos, isLoading } = useQuery({
    queryKey: ["/api/cryptos"],
  });
  
  // Filter cryptos based on search term
  const filteredCryptos = cryptos?.filter(crypto => 
    crypto.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    crypto.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];
  
  const getCryptoIcon = (symbol: string) => {
    switch(symbol) {
      case "BTC":
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-amber-500 flex items-center justify-center text-white">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">
              <path d="M11.767 19.089c4.924.868 9.458-2.422 10.126-7.345.669-4.924-2.796-9.522-7.72-10.39-4.924-.868-9.458 2.422-10.126 7.345-.669 4.924 2.796 9.522 7.72 10.39z" />
              <path d="M15.429 10.97l-3.5 3.5" />
              <path d="M12.429 9.67l1-1 2.5 2.5-1 1" />
              <path d="M11.529 10.37l-1 1-2.5-2.5 1-1" />
              <path d="M9.5 14l1-1" />
              <path d="M14.5 9l1-1" />
            </svg>
          </div>
        );
      case "ETH":
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2L2 12.5 12 16l10-3.5L12 2z" />
              <path d="M2 12.5L12 22l10-9.5" />
              <path d="M12 16v6" />
            </svg>
          </div>
        );
      case "SOL":
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-purple-500 flex items-center justify-center text-white">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 12h4" />
              <path d="M18 12h4" />
              <path d="M7 7l2.51 2.51" />
              <path d="M14.49 14.49L17 17" />
              <path d="M7 17l2.51-2.51" />
              <path d="M14.49 9.51L17 7" />
            </svg>
          </div>
        );
      default:
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-500 flex items-center justify-center text-white">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="16" />
              <line x1="8" y1="12" x2="16" y2="12" />
            </svg>
          </div>
        );
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900">Cryptocurrency Markets</h1>
          <p className="mt-4 text-xl text-gray-600">
            Explore the assets our expert traders actively manage in your portfolio
          </p>
        </div>
        
        <div className="mb-8 relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <Input
            type="text"
            placeholder="Search by name or symbol..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Available Cryptocurrencies</CardTitle>
            <CardDescription>
              Current market prices and performance metrics
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Asset</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">24h Change</TableHead>
                      <TableHead className="text-right">Market Cap</TableHead>
                      <TableHead className="text-right">Vertex ROI</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCryptos.map((crypto) => (
                      <TableRow key={crypto.id} className="hover:bg-gray-50 transition duration-150">
                        <TableCell>
                          <div className="flex items-center">
                            {getCryptoIcon(crypto.symbol)}
                            <div className="ml-4">
                              <div className="font-medium text-gray-900">{crypto.name}</div>
                              <div className="text-gray-500">{crypto.symbol}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          ${parseFloat(crypto.price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </TableCell>
                        <TableCell className={`text-right font-medium ${
                          parseFloat(crypto.change24h) >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          <div className="flex items-center justify-end">
                            {parseFloat(crypto.change24h) >= 0 ? 
                              <TrendingUp className="h-4 w-4 mr-1" /> : 
                              <TrendingDown className="h-4 w-4 mr-1" />
                            }
                            {parseFloat(crypto.change24h) >= 0 ? '+' : ''}
                            {crypto.change24h}%
                          </div>
                        </TableCell>
                        <TableCell className="text-right text-gray-600">
                          ${(parseFloat(crypto.marketCap) / 1e9).toFixed(1)}B
                        </TableCell>
                        <TableCell className="text-right font-medium text-green-600">
                          +{crypto.vertexROI}%
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {filteredCryptos.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                          No cryptocurrencies found matching your search.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
        
        <div className="mt-12 bg-gray-50 rounded-xl p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Our Trading Approach</h2>
          <p className="text-gray-700 mb-4">
            At Vertex Market, we employ a sophisticated combination of technical analysis, fundamental research, and market sentiment to identify profitable trading opportunities in the cryptocurrency market.
          </p>
          <p className="text-gray-700 mb-4">
            Our expert traders continuously monitor market conditions and adjust strategies to maximize returns while managing risk. We focus primarily on established cryptocurrencies with strong fundamentals, high liquidity, and significant growth potential.
          </p>
          <p className="text-gray-700">
            The Vertex ROI indicates our historical performance trading each asset, reflecting our ability to generate returns that significantly outperform simple buy-and-hold strategies.
          </p>
        </div>
      </div>
    </div>
  );
}
