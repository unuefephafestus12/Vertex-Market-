import SimpleLayout from "@/components/SimpleLayout";

export default function SimpleHomePage() {
  return <SimpleLayout />;
}