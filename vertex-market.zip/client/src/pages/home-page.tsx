import HeroSection from "@/components/home/hero-section";
import TrustIndicators from "@/components/home/trust-indicators";
import ProcessSection from "@/components/home/process-section";
import CryptoMarkets from "@/components/home/crypto-markets";
import DashboardPreview from "@/components/home/dashboard-preview";
import TestimonialsSection from "@/components/home/testimonials-section";
import RegisterCTA from "@/components/home/register-cta";
import FaqSection from "@/components/home/faq-section";
import { useQuery } from "@tanstack/react-query";

export default function HomePage() {
  // Fetch cryptocurrencies for the markets section
  const { data: cryptos } = useQuery({
    queryKey: ["/api/cryptos"],
  });
  
  // Fetch testimonials
  const { data: testimonials } = useQuery({
    queryKey: ["/api/testimonials"],
  });
  
  // Fetch FAQs
  const { data: faqs } = useQuery({
    queryKey: ["/api/faqs"],
  });
  
  return (
    <div>
      <HeroSection />
      <TrustIndicators />
      <ProcessSection />
      <CryptoMarkets cryptos={cryptos || []} />
      <DashboardPreview />
      <TestimonialsSection testimonials={testimonials || []} />
      <RegisterCTA />
      <FaqSection faqs={faqs || []} />
    </div>
  );
}
