import { useState } from "react";
import {
  Area,
  AreaChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Button } from "@/components/ui/button";

// Sample data to represent portfolio growth over time
const generatePortfolioData = (period: string) => {
  const baseData = {
    "1W": [
      { date: "Mon", value: 10000 },
      { date: "Tue", value: 10240 },
      { date: "Wed", value: 10180 },
      { date: "Thu", value: 10350 },
      { date: "Fri", value: 10580 },
      { date: "Sat", value: 10720 },
      { date: "Sun", value: 10950 },
    ],
    "1M": [
      { date: "Week 1", value: 10000 },
      { date: "Week 2", value: 10650 },
      { date: "Week 3", value: 11200 },
      { date: "Week 4", value: 12100 },
    ],
    "3M": [
      { date: "Jan", value: 10000 },
      { date: "Feb", value: 11500 },
      { date: "Mar", value: 13642 },
    ],
    "1Y": [
      { date: "Jan", value: 10000 },
      { date: "Feb", value: 10500 },
      { date: "Mar", value: 11200 },
      { date: "Apr", value: 11800 },
      { date: "May", value: 12300 },
      { date: "Jun", value: 11900 },
      { date: "Jul", value: 12500 },
      { date: "Aug", value: 13100 },
      { date: "Sep", value: 13500 },
      { date: "Oct", value: 12900 },
      { date: "Nov", value: 13300 },
      { date: "Dec", value: 13642 },
    ],
  };

  return baseData[period as keyof typeof baseData] || baseData["1M"];
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-gray-200 shadow-md rounded-md">
        <p className="font-medium text-gray-900">{label}</p>
        <p className="text-green-600 font-medium">
          ${payload[0].value.toLocaleString()}
        </p>
      </div>
    );
  }

  return null;
};

export default function PortfolioChart() {
  const [timePeriod, setTimePeriod] = useState("1W");
  const data = generatePortfolioData(timePeriod);

  return (
    <div>
      <div className="flex justify-end space-x-2 mb-4">
        <Button
          variant={timePeriod === "1W" ? "default" : "outline"}
          size="sm"
          onClick={() => setTimePeriod("1W")}
        >
          1W
        </Button>
        <Button
          variant={timePeriod === "1M" ? "default" : "outline"}
          size="sm"
          onClick={() => setTimePeriod("1M")}
        >
          1M
        </Button>
        <Button
          variant={timePeriod === "3M" ? "default" : "outline"}
          size="sm"
          onClick={() => setTimePeriod("3M")}
        >
          3M
        </Button>
        <Button
          variant={timePeriod === "1Y" ? "default" : "outline"}
          size="sm"
          onClick={() => setTimePeriod("1Y")}
        >
          1Y
        </Button>
      </div>
      
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{
              top: 5,
              right: 5,
              left: 5,
              bottom: 5,
            }}
          >
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(216, 100%, 34%)" stopOpacity={0.8} />
                <stop offset="95%" stopColor="hsl(216, 100%, 34%)" stopOpacity={0.1} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
            <XAxis dataKey="date" tick={{ fontSize: 12 }} />
            <YAxis
              tickFormatter={(value) => `$${value.toLocaleString()}`}
              tick={{ fontSize: 12 }}
              domain={['dataMin - 500', 'dataMax + 500']}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="value"
              stroke="hsl(216, 100%, 34%)"
              fillOpacity={1}
              fill="url(#colorValue)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
