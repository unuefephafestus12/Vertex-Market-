import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, TrendingUp, BarChart3 } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  subValue?: string;
  icon: "dollar" | "trending-up" | "chart";
  valueClassName?: string;
}

export default function StatCard({ title, value, subValue, icon, valueClassName = "" }: StatCardProps) {
  const renderIcon = () => {
    switch (icon) {
      case "dollar":
        return <DollarSign className="h-5 w-5 text-primary" />;
      case "trending-up":
        return <TrendingUp className="h-5 w-5 text-green-600" />;
      case "chart":
        return <BarChart3 className="h-5 w-5 text-blue-600" />;
      default:
        return <DollarSign className="h-5 w-5 text-primary" />;
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className={`text-2xl font-bold mt-2 ${valueClassName}`}>{value}</p>
            {subValue && (
              <p className="text-sm text-gray-500 mt-1">{subValue}</p>
            )}
          </div>
          <div className="p-2 bg-gray-100 rounded-full">
            {renderIcon()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
