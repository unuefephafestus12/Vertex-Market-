import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Transaction } from "@shared/schema";
import { format } from "date-fns";
import { useState } from "react";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

interface TransactionsTableProps {
  transactions: Transaction[];
  showPagination?: boolean;
}

export default function TransactionsTable({ transactions, showPagination = false }: TransactionsTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <span className="text-green-500 text-lg">+</span>;
      case "withdrawal":
        return <span className="text-red-500 text-lg">-</span>;
      case "trading_profit":
        return <span className="text-blue-500 text-lg">↗</span>;
      default:
        return <span className="text-gray-500 text-lg">•</span>;
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
            Completed
          </span>
        );
      case "pending":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
            Pending
          </span>
        );
      case "failed":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
            Failed
          </span>
        );
      default:
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };
  
  const getTypeDisplay = (type: string) => {
    switch (type) {
      case "deposit":
        return "Deposit";
      case "withdrawal":
        return "Withdrawal";
      case "trading_profit":
        return "Trading Profit";
      default:
        return type;
    }
  };
  
  const formatAmount = (amount: string, type: string) => {
    const value = parseFloat(amount);
    const formattedValue = Math.abs(value).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 8,
    });
    
    if (type === "deposit" || type === "trading_profit") {
      return <span className="text-green-600">+{formattedValue}</span>;
    } else if (type === "withdrawal") {
      return <span className="text-red-600">-{formattedValue}</span>;
    }
    
    return formattedValue;
  };
  
  // Pagination logic
  const totalPages = Math.ceil(transactions.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentTransactions = transactions.slice(indexOfFirstItem, indexOfLastItem);
  
  return (
    <div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Asset</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead className="text-right">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {(showPagination ? currentTransactions : transactions).map((transaction) => (
              <TableRow key={transaction.id} className="hover:bg-gray-50 transition-colors">
                <TableCell>
                  {format(new Date(transaction.date), "yyyy-MM-dd")}
                </TableCell>
                <TableCell className="flex items-center">
                  {getTypeIcon(transaction.type)}
                  <span className="ml-2">{getTypeDisplay(transaction.type)}</span>
                </TableCell>
                <TableCell>{transaction.asset}</TableCell>
                <TableCell className="text-right">
                  {formatAmount(transaction.amount.toString(), transaction.type)}
                </TableCell>
                <TableCell className="text-right">
                  {getStatusBadge(transaction.status)}
                </TableCell>
              </TableRow>
            ))}
            
            {transactions.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                  No transactions found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      {showPagination && totalPages > 1 && (
        <div className="mt-4">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious 
                  href="#" 
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage(prev => Math.max(prev - 1, 1));
                  }}
                  className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>
              
              {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                let pageNumber = i + 1;
                if (totalPages > 5) {
                  if (currentPage > 3) {
                    pageNumber = currentPage - 3 + i;
                  }
                  if (currentPage + 2 > totalPages) {
                    pageNumber = totalPages - 4 + i;
                  }
                }
                
                return (
                  <PaginationItem key={i}>
                    {pageNumber === currentPage ? (
                      <PaginationLink href="#" isActive>
                        {pageNumber}
                      </PaginationLink>
                    ) : (
                      <PaginationLink 
                        href="#" 
                        onClick={(e) => {
                          e.preventDefault();
                          setCurrentPage(pageNumber);
                        }}
                      >
                        {pageNumber}
                      </PaginationLink>
                    )}
                  </PaginationItem>
                );
              })}
              
              {totalPages > 5 && currentPage < totalPages - 2 && (
                <PaginationItem>
                  <PaginationEllipsis />
                </PaginationItem>
              )}
              
              <PaginationItem>
                <PaginationNext 
                  href="#" 
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage(prev => Math.min(prev + 1, totalPages));
                  }}
                  className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}
    </div>
  );
}
