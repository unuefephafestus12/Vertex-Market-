import { AreaChart, Area, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";

// Sample data for portfolio chart
const portfolioData = [
  { name: "Mon", value: 10000 },
  { name: "Tue", value: 10240 },
  { name: "Wed", value: 10180 },
  { name: "Thu", value: 10350 },
  { name: "Fri", value: 10580 },
  { name: "Sat", value: 10720 },
  { name: "Sun", value: 10950 },
];

// Sample data for pie chart
const pieData = [
  { name: "BTC", value: 40, color: "#F7931A" },
  { name: "ETH", value: 25, color: "#627EEA" },
  { name: "SOL", value: 15, color: "#00A67E" },
  { name: "Others", value: 20, color: "#ADB5BD" },
];

// Sample transactions
const transactions = [
  { date: "2023-05-15", type: "Trading Profit", asset: "BTC", amount: "+0.024 BTC", status: "Completed" },
  { date: "2023-05-12", type: "Deposit", asset: "USD", amount: "+$2,500.00", status: "Completed" },
  { date: "2023-05-10", type: "Withdrawal", asset: "USD", amount: "-$1,000.00", status: "Completed" },
];

export default function DashboardPreview() {
  return (
    <section className="py-16 bg-white overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800">Professional Trading Dashboard</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Monitor your investments with our intuitive, data-rich dashboard designed for both beginners and experts.
          </p>
        </div>
        
        <div className="bg-gray-900 rounded-xl p-4 sm:p-6 shadow-xl relative max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <div className="bg-gray-800 rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-white font-semibold">Portfolio Performance</h3>
                  <div className="flex space-x-2">
                    <button className="bg-gray-700 hover:bg-gray-600 text-white text-xs px-2 py-1 rounded">1D</button>
                    <button className="bg-primary text-white text-xs px-2 py-1 rounded">1W</button>
                    <button className="bg-gray-700 hover:bg-gray-600 text-white text-xs px-2 py-1 rounded">1M</button>
                    <button className="bg-gray-700 hover:bg-gray-600 text-white text-xs px-2 py-1 rounded">1Y</button>
                  </div>
                </div>
                
                <div className="h-64 w-full rounded-lg overflow-hidden">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={portfolioData}>
                      <defs>
                        <linearGradient id="colorPortfolio" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#0047AB" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#0047AB" stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <Area 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#0047AB" 
                        fillOpacity={1} 
                        fill="url(#colorPortfolio)" 
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="mt-3 grid grid-cols-3 gap-2">
                  <div className="bg-gray-700 rounded p-2 text-white">
                    <p className="text-xs opacity-80">Initial Investment</p>
                    <p className="text-lg font-mono font-medium">$10,000.00</p>
                  </div>
                  <div className="bg-gray-700 rounded p-2 text-white">
                    <p className="text-xs opacity-80">Current Value</p>
                    <p className="text-lg font-mono font-medium text-green-400">$13,642.19</p>
                  </div>
                  <div className="bg-gray-700 rounded p-2 text-white">
                    <p className="text-xs opacity-80">Total Profit</p>
                    <p className="text-lg font-mono font-medium text-green-400">+36.42%</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="text-white font-semibold mb-3">Asset Allocation</h3>
                <div className="h-32 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={25}
                        outerRadius={45}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="mt-3 space-y-2">
                  {pieData.map((item, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div 
                          className="w-3 h-3 rounded-full mr-2" 
                          style={{ backgroundColor: item.color }}
                        ></div>
                        <span className="text-white text-sm">{item.name}</span>
                      </div>
                      <span className="text-white text-sm">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="text-white font-semibold mb-3">Quick Actions</h3>
                <div className="grid grid-cols-2 gap-2">
                  <button className="bg-primary hover:bg-primary-dark text-white text-sm p-2 rounded flex items-center justify-center">
                    <span className="mr-1">+</span> Deposit
                  </button>
                  <button className="bg-green-600 hover:bg-green-700 text-white text-sm p-2 rounded flex items-center justify-center">
                    <span className="mr-1">↗</span> Withdraw
                  </button>
                  <button className="bg-gray-700 hover:bg-gray-600 text-white text-sm p-2 rounded flex items-center justify-center">
                    <span className="mr-1">📄</span> Reports
                  </button>
                  <button className="bg-gray-700 hover:bg-gray-600 text-white text-sm p-2 rounded flex items-center justify-center">
                    <span className="mr-1">⚙️</span> Settings
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4 bg-gray-800 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-3">Recent Transactions</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead>
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Date</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Type</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Asset</th>
                    <th className="px-3 py-2 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Amount</th>
                    <th className="px-3 py-2 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {transactions.map((transaction, index) => (
                    <tr key={index}>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-300">{transaction.date}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-300">{transaction.type}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-300">{transaction.asset}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-right" 
                          style={{ color: transaction.amount.startsWith('+') ? '#34D399' : '#F87171' }}>
                        {transaction.amount}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-right">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-900 text-green-300">
                          {transaction.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
