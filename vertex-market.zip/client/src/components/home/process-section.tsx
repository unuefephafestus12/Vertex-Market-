import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function ProcessSection() {
  const steps = [
    {
      number: 1,
      title: "Create Your Account",
      description: "Complete a simple registration process with your basic information and verify your identity.",
      action: {
        text: "Get Started",
        href: "/auth"
      }
    },
    {
      number: 2,
      title: "Fund Your Account",
      description: "Deposit funds using your preferred payment method, including bank transfers and cryptocurrencies.",
      action: {
        text: "Funding Options",
        href: "/dashboard"
      }
    },
    {
      number: 3,
      title: "Watch Your Profits Grow",
      description: "Our expert traders handle everything. Monitor your profits in real-time and withdraw anytime.",
      action: {
        text: "View Performance",
        href: "/dashboard"
      }
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800">How Vertex Market Works</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Our streamlined process makes cryptocurrency investment accessible to everyone.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step) => (
            <div key={step.number} className="bg-gray-100 rounded-xl p-6 relative">
              <div className="absolute -top-4 -left-4 w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center text-xl font-bold">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold mb-3 mt-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
              <Link href={step.action.href}>
                <a className="mt-4 flex items-center text-primary">
                  <span className="font-medium">{step.action.text}</span>
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
