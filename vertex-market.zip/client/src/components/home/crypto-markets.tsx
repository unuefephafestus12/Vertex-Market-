import { Crypto } from "@shared/schema";
import { ArrowRight, TrendingUp, TrendingDown } from "lucide-react";
import { Link } from "wouter";

interface CryptoMarketsProps {
  cryptos: Crypto[];
}

export default function CryptoMarkets({ cryptos }: CryptoMarketsProps) {
  const getCryptoIcon = (symbol: string) => {
    switch(symbol) {
      case "BTC":
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-amber-500 flex items-center justify-center text-white">
            <span className="font-bold">₿</span>
          </div>
        );
      case "ETH":
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary-light flex items-center justify-center text-white">
            <span className="font-bold">Ξ</span>
          </div>
        );
      case "SOL":
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-700 flex items-center justify-center text-white">
            <span className="font-bold">◎</span>
          </div>
        );
      case "ADA":
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-600 flex items-center justify-center text-white">
            <span className="font-bold">₳</span>
          </div>
        );
      default:
        return (
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-500 flex items-center justify-center text-white">
            <span className="font-bold">$</span>
          </div>
        );
    }
  };

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-800">Cryptocurrency Markets</h2>
            <p className="mt-2 text-lg text-gray-600">Our expert traders focus on these top-performing assets</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Link href="/markets">
              <a className="text-primary font-medium flex items-center">
                View All Markets
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Link>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white rounded-xl overflow-hidden shadow-sm">
            <thead className="bg-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Asset</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-600 uppercase tracking-wider">Price</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-600 uppercase tracking-wider">24h Change</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-600 uppercase tracking-wider">Market Cap</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-600 uppercase tracking-wider">Vertex ROI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {cryptos.map((crypto) => (
                <tr key={crypto.id} className="hover:bg-gray-50 transition duration-150">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {getCryptoIcon(crypto.symbol)}
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{crypto.name}</div>
                        <div className="text-sm text-gray-500">{crypto.symbol}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    ${parseFloat(crypto.price).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end">
                      {parseFloat(crypto.change24h) >= 0 ? (
                        <>
                          <TrendingUp className="h-4 w-4 mr-1 text-green-600" />
                          <span className="text-green-600">+{crypto.change24h}%</span>
                        </>
                      ) : (
                        <>
                          <TrendingDown className="h-4 w-4 mr-1 text-red-600" />
                          <span className="text-red-600">{crypto.change24h}%</span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-600">
                    ${(parseFloat(crypto.marketCap) / 1e9).toFixed(1)}B
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-green-600">
                    +{crypto.vertexROI}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
