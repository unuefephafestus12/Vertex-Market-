import { useState } from "react";
import { Faq } from "@shared/schema";
import { ChevronDown, ChevronUp } from "lucide-react";

interface FaqSectionProps {
  faqs: Faq[];
}

export default function FaqSection({ faqs }: FaqSectionProps) {
  const [openIndex, setOpenIndex] = useState(0);
  
  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? -1 : index);
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800">Frequently Asked Questions</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions about Vertex Market.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={faq.id} className="border border-gray-200 rounded-lg">
                <button 
                  className="flex justify-between items-center w-full px-6 py-4 text-left focus:outline-none"
                  onClick={() => toggleFaq(index)}
                >
                  <span className="font-medium text-gray-800">{faq.question}</span>
                  {openIndex === index ? (
                    <ChevronUp className="text-gray-500 h-5 w-5" />
                  ) : (
                    <ChevronDown className="text-gray-500 h-5 w-5" />
                  )}
                </button>
                <div className={`px-6 pb-4 text-gray-600 ${openIndex === index ? '' : 'hidden'}`}>
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
            
            {faqs.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-500">No FAQs available at the moment.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
