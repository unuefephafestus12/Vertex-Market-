import { Shield, Lock, Eye, Building, Headphones } from "lucide-react";

export default function TrustIndicators() {
  const indicators = [
    {
      icon: <Shield className="h-5 w-5 text-primary" />,
      text: "256-bit Encryption"
    },
    {
      icon: <Lock className="h-5 w-5 text-primary" />,
      text: "Secure Storage"
    },
    {
      icon: <Eye className="h-5 w-5 text-primary" />,
      text: "Transparent Fees"
    },
    {
      icon: <Building className="h-5 w-5 text-primary" />,
      text: "Regulated Entity"
    },
    {
      icon: <Headphones className="h-5 w-5 text-primary" />,
      text: "24/7 Support"
    }
  ];

  return (
    <section className="bg-white py-6 border-b border-gray-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {indicators.map((indicator, index) => (
            <div key={index} className="flex items-center space-x-2">
              {indicator.icon}
              <span className="text-sm font-medium">{indicator.text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
