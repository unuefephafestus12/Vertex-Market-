import { Link, useLocation } from "wouter";

export default function SimpleLayout() {
  const [location, navigate] = useLocation();
  
  const handleGetStarted = () => {
    navigate("/auth");
  };
  
  return (
    <div className="simple-layout">
      <header>
        <h1>Vertex Market</h1>
        <nav>
          <ul>
            <li><Link href="/">Home</Link></li>
            <li><Link href="/about">About</Link></li>
            <li><Link href="/dashboard">Dashboard</Link></li>
            <li><Link href="/testimonials">Testimonials</Link></li>
            <li><Link href="/support">Contact</Link></li>
          </ul>
        </nav>
      </header>

      <section className="hero">
        <h2>Welcome to Vertex Market</h2>
        <p>Your trusted cryptocurrency trading platform.</p>
        <button onClick={handleGetStarted}>Get Started</button>
      </section>

      <section className="features">
        <div className="feature-card">
          <h3>Expert Trading</h3>
          <p>Our professional traders work around the clock to maximize your returns.</p>
        </div>
        <div className="feature-card">
          <h3>Secure Platform</h3>
          <p>Advanced security measures to keep your investments safe.</p>
        </div>
        <div className="feature-card">
          <h3>Real-time Updates</h3>
          <p>Track your investments and profits in real time.</p>
        </div>
      </section>

      <section className="cta-section">
        <h2>Ready to Start Investing?</h2>
        <p>Join thousands of investors who trust Vertex Market for their cryptocurrency investments.</p>
        <button onClick={handleGetStarted}>Create Your Account</button>
      </section>

      <footer>
        <p>&copy; 2025 Vertex Market. All rights reserved.</p>
      </footer>
    </div>
  );
}