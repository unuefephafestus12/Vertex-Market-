import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import MarketsPage from "@/pages/markets";
import AboutPage from "@/pages/about";
import TestimonialsPage from "@/pages/testimonials";
import SupportPage from "@/pages/support";
import SimpleHomePage from "@/pages/simple-home";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import Navbar from "./components/ui/navbar";
import Footer from "./components/ui/footer";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Switch>
        <Route path="/simple" component={SimpleHomePage} />
        <Route>
          <Navbar />
          <main className="flex-grow">
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/auth" component={AuthPage} />
              <ProtectedRoute path="/dashboard" component={Dashboard} />
              <Route path="/markets" component={MarketsPage} />
              <Route path="/about" component={AboutPage} />
              <Route path="/testimonials" component={TestimonialsPage} />
              <Route path="/support" component={SupportPage} />
              <Route component={NotFound} />
            </Switch>
          </main>
          <Footer />
        </Route>
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
