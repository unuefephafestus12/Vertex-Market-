import { pgTable, text, serial, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("firstName").notNull(),
  lastName: text("lastName").notNull(),
  email: text("email").notNull(),
  phoneNumber: text("phoneNumber"),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  email: true,
  phoneNumber: true,
});

// Cryptocurrency schema
export const cryptocurrencies = pgTable("cryptocurrencies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull().unique(),
  price: decimal("price", { precision: 24, scale: 8 }).notNull(),
  change24h: decimal("change24h", { precision: 10, scale: 2 }),
  marketCap: decimal("marketCap", { precision: 24, scale: 2 }),
  vertexROI: decimal("vertexROI", { precision: 10, scale: 2 }),
});

export const insertCryptoSchema = createInsertSchema(cryptocurrencies).pick({
  name: true,
  symbol: true,
  price: true,
  change24h: true,
  marketCap: true,
  vertexROI: true,
});

// Investment schema
export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  amount: decimal("amount", { precision: 24, scale: 2 }).notNull(),
  currentValue: decimal("currentValue", { precision: 24, scale: 2 }).notNull(),
  profit: decimal("profit", { precision: 24, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const insertInvestmentSchema = createInsertSchema(investments).pick({
  userId: true,
  amount: true,
  currentValue: true,
  profit: true,
});

// Transactions schema
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  type: text("type").notNull(), // deposit, withdrawal, trading_profit
  asset: text("asset").notNull(),
  amount: decimal("amount", { precision: 24, scale: 8 }).notNull(),
  status: text("status").notNull(), // pending, completed, failed
  date: timestamp("date").defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  type: true,
  asset: true,
  amount: true,
  status: true,
});

// Withdrawal requests schema
export const withdrawalRequests = pgTable("withdrawalRequests", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  amount: decimal("amount", { precision: 24, scale: 2 }).notNull(),
  status: text("status").notNull(), // pending, approved, rejected
  method: text("method").notNull(), // bank, crypto
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const insertWithdrawalSchema = createInsertSchema(withdrawalRequests).pick({
  userId: true,
  amount: true,
  status: true,
  method: true,
  details: true,
});

// Testimonial schema
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  profession: text("profession"),
  content: text("content").notNull(),
  rating: integer("rating").notNull(),
  verified: boolean("verified").default(true),
});

export const insertTestimonialSchema = createInsertSchema(testimonials).pick({
  name: true,
  profession: true,
  content: true,
  rating: true,
  verified: true,
});

// FAQ schema
export const faqs = pgTable("faqs", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  order: integer("order"),
});

export const insertFaqSchema = createInsertSchema(faqs).pick({
  question: true,
  answer: true,
  order: true,
});

// Asset allocation schema
export const assetAllocation = pgTable("assetAllocation", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  cryptoId: integer("cryptoId").notNull(),
  percentage: decimal("percentage", { precision: 5, scale: 2 }).notNull(),
});

export const insertAssetAllocationSchema = createInsertSchema(assetAllocation).pick({
  userId: true,
  cryptoId: true,
  percentage: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCrypto = z.infer<typeof insertCryptoSchema>;
export type Crypto = typeof cryptocurrencies.$inferSelect;

export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;
export type Investment = typeof investments.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export type InsertWithdrawal = z.infer<typeof insertWithdrawalSchema>;
export type Withdrawal = typeof withdrawalRequests.$inferSelect;

export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

export type InsertFaq = z.infer<typeof insertFaqSchema>;
export type Faq = typeof faqs.$inferSelect;

export type InsertAssetAllocation = z.infer<typeof insertAssetAllocationSchema>;
export type AssetAllocation = typeof assetAllocation.$inferSelect;
